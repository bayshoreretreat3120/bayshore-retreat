import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const pool = mysql.createPool({
  connectionLimit: 1,
  host: process.env.DATABASE_URL?.split('@')[1]?.split('/')[0] || 'localhost',
  user: process.env.DATABASE_URL?.split('://')[1]?.split(':')[0] || 'root',
  password: process.env.DATABASE_URL?.split(':')[1]?.split('@')[0] || '',
  database: process.env.DATABASE_URL?.split('/').pop() || 'test',
});

async function promoteAdmins() {
  try {
    const connection = await pool.getConnection();
    
    // Promote realtor@jaywaddell.com
    await connection.execute(
      'UPDATE users SET role = ? WHERE email = ?',
      ['admin', 'realtor@jaywaddell.com']
    );
    console.log('✓ Promoted realtor@jaywaddell.com to admin');
    
    // Promote tourintpa@gmail.com
    await connection.execute(
      'UPDATE users SET role = ? WHERE email = ?',
      ['admin', 'tourintpa@gmail.com']
    );
    console.log('✓ Promoted tourintpa@gmail.com to admin');
    
    // Verify
    const [rows] = await connection.execute(
      'SELECT email, role FROM users WHERE role = ?',
      ['admin']
    );
    console.log('\nCurrent admin users:');
    rows.forEach(row => console.log(`  - ${row.email} (${row.role})`));
    
    connection.release();
    process.exit(0);
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

promoteAdmins();
