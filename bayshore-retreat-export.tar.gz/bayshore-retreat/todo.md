# Bayshore Retreat TODO

## Completed Features
- [x] Created simple admin reviews dashboard at /admin/reviews with Manus email verification
- [x] Promoted both realtor@jaywaddell.com and tourintpa@gmail.com to admin role
- [x] Added VRBO booking link to home page (Expedia listing)
- [x] Set up email notifications to tourintpa@gmail.com for new review submissions
- [x] Built full-featured landing page with "Coastal Editorial" design
- [x] Integrated 35 real property photos from uploads
- [x] Created dedicated Local Guide page (/local-guide)
- [x] Added key attractions: G.T. Bray Park, Manatee Memorial Hospital, IMG Academy, Bradenton Riverwalk
- [x] Generated optimized listing copy for 5 platforms (Airbnb, VRBO, Booking.com, Furnished Finder, Google)
- [x] Created reusable skill: `str-listing-copy`
- [x] Fixed Airbnb booking link to correct URL
- [x] Removed VRBO/Booking.com buttons until listings go live
- [x] Updated check-out time to 10:00 AM
- [x] Changed property description from "bungalow" to "contemporary home"
- [x] Removed photo labels from gallery
- [x] Set up DNS on Namecheap for visitbayshoreretreat.com domain
- [x] Upgraded project from static to web-db-user (backend + database + auth)
- [x] Fixed TypeScript dependency conflicts
- [x] Database schema ready for reviews table
- [x] Added real Airbnb reviews from Greg and Janice (5-star ratings)
- [x] Built moderated guest reviews system:
  - [x] Public review submission form with name, rating (1-5 stars), and review text
  - [x] Admin dashboard for Amanda to approve/reject pending reviews
  - [x] Reviews display section on main site showing approved reviews with star ratings
  - [x] Backend API procedures for submit, retrieve approved, retrieve pending, approve, reject
  - [x] Database schema with reviews table (id, guestName, guestEmail, rating, reviewText, status, createdAt, updatedAt)
  - [x] Vitest tests for all reviews system functionality (8 tests passing)
- [x] Added review count badge ("★ X Verified Reviews")
- [x] Created testimonials carousel with auto-advance and manual navigation
- [x] Built bulk review import tool for manual Airbnb review syncing

## Pending Features
- [ ] Add iCal availability calendar
- [ ] Add VRBO/Booking.com links when listings go live
- [ ] Consider Stripe integration after 90 days
- [ ] Set up automated email notifications for new reviews
- [ ] Add review response capability for Amanda
- [ ] Implement review sorting/filtering options
- [ ] Add review analytics dashboard

## Notes
- Reviews are public-facing: guests can submit reviews without authentication
- Admin dashboard at /admin/reviews requires Amanda to log in with Manus OAuth
- All reviews start with "pending" status and must be approved by admin before displaying
- Reviews display in reverse chronological order (newest first)
- Pricing: $900 onboarding + $500/month management fee
- Domain: visitbayshoreretreat.com (configured via Namecheap)
