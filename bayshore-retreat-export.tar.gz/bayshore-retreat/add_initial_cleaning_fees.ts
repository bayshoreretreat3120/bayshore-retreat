import { getDb } from "./server/db";
import { cleaningFees } from "./drizzle/schema";

const initialFees = [
  { guestName: "Shanta's group of 4", checkInDate: "Apr 17", checkOutDate: "Apr 19", nights: 2, cleaningFee: 10500 }, // $105.00
  { guestName: "Aspen's group of 4", checkInDate: "Apr 24", checkOutDate: "Apr 26", nights: 2, cleaningFee: 11000 }, // $110.00
  { guestName: "Gregory Moore", checkInDate: "Apr 26", checkOutDate: "Apr 27", nights: 1, cleaningFee: 12000 }, // $120.00
  { guestName: "Lindsay's group of 2", checkInDate: "Apr 27", checkOutDate: "Apr 29", nights: 2, cleaningFee: 12000 }, // $120.00
  { guestName: "Grant's group of 4", checkInDate: "May 1", checkOutDate: "May 3", nights: 2, cleaningFee: 12000 }, // $120.00
];

async function addInitialFees() {
  try {
    const db = await getDb();
    if (!db) {
      console.error("Database not available");
      return;
    }

    console.log("Adding initial cleaning fees...");
    
    for (const fee of initialFees) {
      await db.insert(cleaningFees).values({
        guestName: fee.guestName,
        checkInDate: fee.checkInDate,
        checkOutDate: fee.checkOutDate,
        nights: fee.nights,
        cleaningFee: fee.cleaningFee,
      });
      console.log(`✓ Added cleaning fee for ${fee.guestName}: $${(fee.cleaningFee / 100).toFixed(2)}`);
    }

    const total = initialFees.reduce((sum, fee) => sum + fee.cleaningFee, 0);
    console.log(`\n✓ Successfully added ${initialFees.length} cleaning fees`);
    console.log(`Total: $${(total / 100).toFixed(2)}`);
  } catch (error) {
    console.error("Error adding initial cleaning fees:", error);
    process.exit(1);
  }
}

addInitialFees();
