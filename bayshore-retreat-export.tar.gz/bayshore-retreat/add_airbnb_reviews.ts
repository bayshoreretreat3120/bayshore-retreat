import { getDb } from "./server/db";
import { reviews } from "./drizzle/schema";
import { eq } from "drizzle-orm";

async function updateReviews() {
  try {
    const db = await getDb();
    if (!db) {
      console.error("Failed to connect to database");
      process.exit(1);
    }
    
    // Delete the test review from "Test Guest"
    await db.delete(reviews)
      .where(eq(reviews.guestName, "Test Guest"));
    console.log("✓ Deleted test review from 'Test Guest'");
    
    // Add Greg's review
    await db.insert(reviews).values({
      guestName: "Greg",
      rating: 5,
      reviewText: "Amanda and Jay were great hosts. I was needing a place go a few days while contractors were working on my house and this place was only 4 blocks from me. The house was very nice and clean and we would definitely stay there again",
      status: "approved",
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
    });
    console.log("✓ Added Greg's review");
    
    // Add Janice's review
    await db.insert(reviews).values({
      guestName: "Janice",
      rating: 5,
      reviewText: "Host was amazing, flexible check in allowed me extra time for check out and place looked even more beautiful than the pics. My kids and nephews enjoyed a lot!",
      status: "approved",
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
    });
    console.log("✓ Added Janice's review");
    
    console.log("\n✓ All reviews updated successfully!");
    process.exit(0);
  } catch (error) {
    console.error("Error:", error);
    process.exit(1);
  }
}

updateReviews();
