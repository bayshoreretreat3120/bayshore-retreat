import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME } from "@shared/const";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, adminProcedure } from "./_core/trpc";
import { z } from "zod";
import { submitReview, getApprovedReviews, getPendingReviews, approveReview, rejectReview, addCleaningFee, getCleaningFees, deleteCleaningFee, updateCleaningFee } from "./db";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  reviews: router({
    submit: publicProcedure
      .input(z.object({
        guestName: z.string().min(1, "Guest name is required"),
        rating: z.number().min(1).max(5, "Rating must be between 1 and 5"),
        reviewText: z.string().min(10, "Review must be at least 10 characters"),
      }))
      .mutation(async ({ input }) => {
        try {
          await submitReview({
            guestName: input.guestName,
            rating: input.rating,
            reviewText: input.reviewText,
            status: "pending",
            createdAt: new Date(),
          });
          
          // Send email notification to admin
          await notifyOwner({
            title: `New Review Submitted - ${input.guestName}`,
            content: `A new review has been submitted and is pending approval.\n\nGuest: ${input.guestName}\nRating: ${input.rating}/5 stars\n\nReview:\n${input.reviewText}\n\nPlease log in to the admin dashboard at /admin/reviews to approve or reject this review.`,
          });
          
          return { success: true };
        } catch (error) {
          console.error("Failed to submit review:", error);
          throw error;
        }
      }),
    
    approved: publicProcedure.query(async () => {
      return getApprovedReviews();
    }),
    
    pending: adminProcedure.query(async () => {
      return getPendingReviews();
    }),
    
    approve: adminProcedure
      .input(z.object({ reviewId: z.number() }))
      .mutation(async ({ input }) => {
        await approveReview(input.reviewId);
        return { success: true };
      }),
    
    reject: adminProcedure
      .input(z.object({ reviewId: z.number() }))
      .mutation(async ({ input }) => {
        await rejectReview(input.reviewId);
        return { success: true };
      }),
  }),

  cleaningFees: router({
    add: adminProcedure
      .input(z.object({
        guestName: z.string().min(1, "Guest name is required"),
        checkInDate: z.string().min(1, "Check-in date is required"),
        checkOutDate: z.string().min(1, "Check-out date is required"),
        nights: z.number().min(1, "Number of nights is required"),
        cleaningFee: z.number().min(0, "Cleaning fee must be positive"),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await addCleaningFee({
          guestName: input.guestName,
          checkInDate: input.checkInDate,
          checkOutDate: input.checkOutDate,
          nights: input.nights,
          cleaningFee: input.cleaningFee,
          notes: input.notes,
        });
        return { success: true };
      }),
    
    list: adminProcedure.query(async () => {
      return getCleaningFees();
    }),
    
    delete: adminProcedure
      .input(z.object({ feeId: z.number() }))
      .mutation(async ({ input }) => {
        await deleteCleaningFee(input.feeId);
        return { success: true };
      }),
    
    update: adminProcedure
      .input(z.object({
        feeId: z.number(),
        guestName: z.string().optional(),
        checkInDate: z.string().optional(),
        checkOutDate: z.string().optional(),
        nights: z.number().optional(),
        cleaningFee: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { feeId, ...updates } = input;
        await updateCleaningFee(feeId, updates);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
