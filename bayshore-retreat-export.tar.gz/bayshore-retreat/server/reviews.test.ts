import { describe, it, expect, beforeAll } from "vitest";
import { submitReview, getApprovedReviews, getPendingReviews, approveReview, rejectReview } from "./db";

describe("Reviews System", () => {
  let testReviewId: number;

  it("should submit a new review with pending status", async () => {
    const result = await submitReview({
      guestName: "Test Guest",
      rating: 5,
      reviewText: "This is a wonderful place to stay! The property is beautiful and well-maintained.",
      status: "pending",
      createdAt: new Date(),
    });

    expect(result).toBeDefined();
    // Store the ID for later tests
    testReviewId = (result as any).insertId || 1;
  });

  it("should retrieve pending reviews", async () => {
    const pending = await getPendingReviews();
    expect(Array.isArray(pending)).toBe(true);
    expect(pending.length).toBeGreaterThan(0);
    
    const testReview = pending.find((r) => r.guestName === "Test Guest");
    expect(testReview).toBeDefined();
    expect(testReview?.status).toBe("pending");
  });

  it("should approve a review", async () => {
    const pending = await getPendingReviews();
    const testReview = pending.find((r) => r.guestName === "Test Guest");
    
    if (testReview) {
      await approveReview(testReview.id);
      
      const approved = await getApprovedReviews();
      const approvedReview = approved.find((r) => r.id === testReview.id);
      expect(approvedReview).toBeDefined();
      expect(approvedReview?.status).toBe("approved");
    }
  });

  it("should retrieve approved reviews", async () => {
    const approved = await getApprovedReviews();
    expect(Array.isArray(approved)).toBe(true);
    
    const testReview = approved.find((r) => r.guestName === "Test Guest");
    expect(testReview).toBeDefined();
    expect(testReview?.rating).toBe(5);
  });

  it("should reject a review", async () => {
    // Submit another test review
    await submitReview({
      guestName: "Reject Test Guest",
      rating: 2,
      reviewText: "This review will be rejected for testing purposes.",
      status: "pending",
      createdAt: new Date(),
    });

    const pending = await getPendingReviews();
    const rejectReviewTest = pending.find((r) => r.guestName === "Reject Test Guest");
    
    if (rejectReviewTest) {
      await rejectReview(rejectReviewTest.id);
      
      // Verify it's no longer in pending
      const updatedPending = await getPendingReviews();
      const stillPending = updatedPending.find((r) => r.id === rejectReviewTest.id);
      expect(stillPending).toBeUndefined();
    }
  });

  it("should validate review input", async () => {
    // Test that empty guest name is rejected
    try {
      await submitReview({
        guestName: "",
        rating: 5,
        reviewText: "This should fail because guest name is empty.",
        status: "pending",
        createdAt: new Date(),
      });
      // If we get here, the test fails because validation should have thrown
      expect(true).toBe(false);
    } catch (error) {
      // Expected to fail
      expect(error).toBeDefined();
    }
  });

  it("should validate rating range", async () => {
    // Test that rating outside 1-5 range is rejected
    try {
      await submitReview({
        guestName: "Invalid Rating Guest",
        rating: 10, // Invalid: should be 1-5
        reviewText: "This should fail because rating is out of range.",
        status: "pending",
        createdAt: new Date(),
      });
      expect(true).toBe(false);
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});
