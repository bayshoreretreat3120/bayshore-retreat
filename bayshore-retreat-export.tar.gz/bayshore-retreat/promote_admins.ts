import { getDb } from "./server/db";
import { users } from "./drizzle/schema";
import { eq } from "drizzle-orm";

async function promoteAdmins() {
  try {
    const db = await getDb();
    if (!db) {
      console.error("Failed to connect to database");
      process.exit(1);
    }
    
    // Promote realtor@jaywaddell.com
    await db.update(users)
      .set({ role: "admin" })
      .where(eq(users.email, "realtor@jaywaddell.com"));
    console.log("✓ Promoted realtor@jaywaddell.com to admin");
    
    // Promote tourintpa@gmail.com
    await db.update(users)
      .set({ role: "admin" })
      .where(eq(users.email, "tourintpa@gmail.com"));
    console.log("✓ Promoted tourintpa@gmail.com to admin");
    
    console.log("\n✓ Both admin accounts are now promoted!");
    process.exit(0);
  } catch (error) {
    console.error("Error:", error);
    process.exit(1);
  }
}

promoteAdmins();
