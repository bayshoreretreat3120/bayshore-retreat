CREATE TABLE `cleaningFees` (
	`id` int AUTO_INCREMENT NOT NULL,
	`guestName` varchar(255) NOT NULL,
	`checkInDate` varchar(50) NOT NULL,
	`checkOutDate` varchar(50) NOT NULL,
	`nights` int NOT NULL,
	`cleaningFee` int NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cleaningFees_id` PRIMARY KEY(`id`)
);
