/**
 * Local Guide — Bayshore Retreat
 * Simple, clean page showcasing nearby beaches, dining, and activities.
 */

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Waves,
  UtensilsCrossed,
  Compass,
  MapPin,
  ArrowLeft,
  Menu,
  X,
} from "lucide-react";

const CDN = "https://d2xsxph8kpxj0f.cloudfront.net/106775624/FuHS7qG5mXXwEMYBgoL5nB";
const LOGO_URL = `${CDN}/bayshore-logo-transparent_34e15653.png`;
const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/106775624/FuHS7qG5mXXwEMYBgoL5nB/anna-maria-beach_38b7e1a9.jpg";

const BEACHES = [
  { name: "Anna Maria Island", distance: "9 mi", desc: "Sugar-white sand, turquoise Gulf waters, and a free island trolley. Bean Point at the north tip is perfect for shelling and sunsets." },
  { name: "Bradenton Beach", distance: "9 mi", desc: "Laid-back beach town with waterfront dining, boutique shops on Bridge Street, and the Historic Bridge Street Pier." },
  { name: "Coquina Beach", distance: "10 mi", desc: "Wide sandy beach with free parking, picnic shelters, a playground, and the Coquina Baywalk nature trail. Less crowded, great for families." },
  { name: "Palma Sola Causeway", distance: "7 mi", desc: "Calm bay waters ideal for paddleboarding, kayaking, and jet-ski rentals. One of the best sunset spots in Bradenton." },
];

const DINING = [
  { name: "Star Fish Company", distance: "7 mi", desc: "Iconic waterfront seafood in the historic Cortez fishing village. Fresh-off-the-boat grouper and stone crab. Cash only." },
  { name: "Pier 22", distance: "5 mi", desc: "Upscale waterfront dining on the Manatee River. Fresh seafood, craft cocktails, and stunning sunset views." },
  { name: "Mean Deans Local Kitchen", distance: "1.5 mi", desc: "Voted Top 3 in Bradenton. Creative comfort food, craft beers, and a laid-back neighborhood vibe. Minutes from the house." },
  { name: "Beach House Restaurant", distance: "9 mi", desc: "Beachfront dining with toes-in-the-sand seating on Anna Maria Island. Gulf seafood, tropical cocktails, and live music." },
  { name: "Anna Maria Oyster Bar", distance: "5 mi", desc: "Local institution with fresh oysters, grouper sandwiches, and a family-friendly atmosphere. Multiple locations." },
  { name: "Oak & Stone", distance: "3 mi", desc: "Rooftop bar overlooking the Manatee River, a self-serve beer wall with 64 taps, and excellent wood-fired pizza." },
];

const ACTIVITIES = [
  { name: "G.T. Bray Park", distance: "1.5 mi", desc: "Bradenton's massive recreational hub. 8 clay tennis courts, 3 basketball courts, fishing ponds, picnic pavilions ($50 rental fee), and bayou access. Perfect for active families." },
  { name: "Bradenton Riverwalk", distance: "5 mi", desc: "1.5-mile waterfront promenade with splash pads, playgrounds, public art, a skate park, and regular live events." },
  { name: "IMG Academy", distance: "2.5 mi", desc: "World-renowned sports training facility. Ideal for families attending camps, tournaments, and showcases." },
  { name: "Robinson Preserve", distance: "8 mi", desc: "682 acres of boardwalk trails, observation towers with panoramic views, kayak launches, and mangrove forests. Free entry." },
  { name: "De Soto National Memorial", distance: "6 mi", desc: "National park with nature trails through mangroves, ranger-led kayak tours, and living history demonstrations. Free admission." },
  { name: "Cortez Fishing Village", distance: "7 mi", desc: "One of the last working fishing villages in Florida. Fresh seafood markets, boat tours, and the Florida Maritime Museum." },
  { name: "Bishop Museum", distance: "5 mi", desc: "Planetarium, aquarium, manatee rehabilitation center, and interactive science exhibits. Great for kids and rainy days." },
  { name: "Manatee Memorial Hospital", distance: "4 mi", desc: "Major regional medical center. Ideal for travel nurses and healthcare professionals attending training or working temporary assignments." },
];

function Section({ title, icon: Icon, items, color }: { title: string; icon: any; items: { name: string; distance: string; desc: string }[]; color: string }) {
  return (
    <section className="mb-16 last:mb-0">
      <div className="flex items-center gap-3 mb-8">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${color}`}>
          <Icon size={20} className="text-terracotta" />
        </div>
        <h2 className="text-2xl md:text-3xl text-charcoal" style={{ fontFamily: "var(--font-display)" }}>
          {title}
        </h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {items.map((item) => (
          <div
            key={item.name}
            className="p-5 bg-warm-white rounded-xl border border-sand-dark/10 hover:shadow-md transition-shadow duration-300"
          >
            <div className="flex items-start justify-between mb-2">
              <h3 className="text-lg text-charcoal font-semibold" style={{ fontFamily: "var(--font-body)" }}>
                {item.name}
              </h3>
              <span className="text-xs text-charcoal-light bg-sand/60 px-2.5 py-1 rounded-full shrink-0 ml-3" style={{ fontFamily: "var(--font-body)" }}>
                {item.distance}
              </span>
            </div>
            <p className="text-charcoal-light text-sm leading-relaxed" style={{ fontFamily: "var(--font-body)" }}>
              {item.desc}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function LocalGuide() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <div className="min-h-screen" style={{ fontFamily: "var(--font-body)" }}>
      {/* ── NAV ── */}
      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          scrolled
            ? "bg-warm-white/95 backdrop-blur-md shadow-sm py-3"
            : "bg-transparent py-5"
        }`}
      >
        <div className="container flex items-center justify-between">
          <a href="/" className="flex items-center gap-3">
            <img src={LOGO_URL} alt="Bayshore Retreat" className="h-10 w-auto" />
          </a>
          <div className="hidden md:flex items-center gap-8">
            {[
              { label: "Home", href: "/" },
              { label: "Beaches", href: "#beaches" },
              { label: "Dining", href: "#dining" },
              { label: "Activities", href: "#activities" },
            ].map((item) => (
              <a
                key={item.label}
                href={item.href}
                className={`text-sm font-medium tracking-wide transition-colors ${
                  scrolled
                    ? "text-charcoal hover:text-terracotta"
                    : "text-white/90 hover:text-white"
                }`}
              >
                {item.label}
              </a>
            ))}
          </div>
          <a
            href="/#book-now"
            className={`hidden sm:inline-flex items-center px-5 py-2.5 rounded-full text-sm font-semibold transition-all ${
              scrolled
                ? "bg-terracotta text-white hover:bg-terracotta-dark"
                : "bg-white/20 text-white backdrop-blur-sm hover:bg-white/30 border border-white/30"
            }`}
          >
            Book Your Stay
          </a>
          <button
            className={`md:hidden p-2 rounded-lg transition-colors ${
              scrolled ? "text-charcoal hover:bg-sand" : "text-white hover:bg-white/10"
            }`}
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`md:hidden px-4 pb-4 ${
              scrolled ? "bg-warm-white/95 backdrop-blur-md" : "bg-black/80 backdrop-blur-md"
            }`}
          >
            <div className="flex flex-col gap-3">
              <a href="/" onClick={() => setMobileMenuOpen(false)} className={`text-sm font-medium py-2 ${scrolled ? "text-charcoal" : "text-white/90"}`}>Home</a>
              <a href="#beaches" onClick={() => setMobileMenuOpen(false)} className={`text-sm font-medium py-2 ${scrolled ? "text-charcoal" : "text-white/90"}`}>Beaches</a>
              <a href="#dining" onClick={() => setMobileMenuOpen(false)} className={`text-sm font-medium py-2 ${scrolled ? "text-charcoal" : "text-white/90"}`}>Dining</a>
              <a href="#activities" onClick={() => setMobileMenuOpen(false)} className={`text-sm font-medium py-2 ${scrolled ? "text-charcoal" : "text-white/90"}`}>Activities</a>
              <a href="/#book-now" onClick={() => setMobileMenuOpen(false)} className="inline-flex items-center justify-center px-5 py-2.5 bg-terracotta text-white rounded-full text-sm font-semibold mt-1">Book Your Stay</a>
            </div>
          </motion.div>
        )}
      </nav>

      {/* ── HERO ── */}
      <section className="relative h-[50vh] min-h-[360px] flex items-end">
        <div className="absolute inset-0">
          <img src={HERO_IMG} alt="Anna Maria Island Beach" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
        </div>
        <div className="container relative z-10 pb-12">
          <a href="/" className="inline-flex items-center gap-2 text-white/70 text-sm mb-4 hover:text-white transition-colors">
            <ArrowLeft size={16} />
            Back to Bayshore Retreat
          </a>
          <h1 className="text-4xl md:text-5xl text-white" style={{ fontFamily: "var(--font-display)" }}>
            Local Guide
          </h1>
          <p className="text-white/80 text-lg mt-3 max-w-xl">
            Our favorite beaches, restaurants, and things to do near the property.
          </p>
        </div>
      </section>

      {/* ── CONTENT ── */}
      <main className="py-16 md:py-20 bg-cream">
        <div className="container max-w-4xl">
          <div className="flex items-center gap-2 text-charcoal-light text-sm mb-12">
            <MapPin size={14} className="text-terracotta" />
            <span>All distances measured from 3120 Mercer Rd, Bradenton, FL</span>
          </div>

          <div id="beaches">
            <Section title="Beaches" icon={Waves} items={BEACHES} color="bg-terracotta/10" />
          </div>
          <div id="dining">
            <Section title="Dining" icon={UtensilsCrossed} items={DINING} color="bg-terracotta/10" />
          </div>
          <div id="activities">
            <Section title="Activities & Recreation" icon={Compass} items={ACTIVITIES} color="bg-terracotta/10" />
          </div>
        </div>
      </main>

      {/* ── FOOTER ── */}
      <footer className="bg-charcoal text-white py-10">
        <div className="container text-center">
          <img src={LOGO_URL} alt="Bayshore Retreat" className="h-10 w-auto mx-auto mb-4" style={{ filter: "brightness(0) invert(1)" }} />
          <p className="text-white/40 text-sm mb-4">3120 Mercer Rd, Bradenton, FL 34207</p>
          <a href="/" className="text-terracotta-light text-sm hover:text-terracotta transition-colors">
            &larr; Back to Home
          </a>
          <div className="border-t border-white/10 mt-8 pt-6">
            <p className="text-white/30 text-xs">
              &copy; {new Date().getFullYear()} Bayshore Retreat. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
