import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";

export function ReviewSubmissionForm() {
  const [guestName, setGuestName] = useState("");
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const submitReviewMutation = trpc.reviews.submit.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!guestName.trim()) {
      setError("Please enter your name");
      return;
    }

    if (reviewText.trim().length < 10) {
      setError("Review must be at least 10 characters");
      return;
    }

    try {
      await submitReviewMutation.mutateAsync({
        guestName: guestName.trim(),
        rating,
        reviewText: reviewText.trim(),
      });
      setSubmitted(true);
      setGuestName("");
      setRating(5);
      setReviewText("");
      setTimeout(() => setSubmitted(false), 5000);
    } catch (err) {
      setError("Failed to submit review. Please try again.");
      console.error(err);
    }
  };

  return (
    <div className="bg-warm-white rounded-xl border border-sand-dark/20 p-8 max-w-2xl mx-auto">
      <h3 className="text-2xl text-charcoal mb-6" style={{ fontFamily: "var(--font-display)" }}>
        Share Your Experience
      </h3>

      {submitted && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-800 text-sm">
            Thank you! Your review has been submitted and is pending approval.
          </p>
        </div>
      )}

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-800 text-sm">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Guest Name */}
        <div>
          <label className="block text-charcoal font-semibold mb-2" style={{ fontFamily: "var(--font-body)" }}>
            Your Name
          </label>
          <input
            type="text"
            value={guestName}
            onChange={(e) => setGuestName(e.target.value)}
            placeholder="Enter your name"
            className="w-full px-4 py-2 border border-sand-dark/20 rounded-lg focus:outline-none focus:border-terracotta"
            style={{ fontFamily: "var(--font-body)" }}
          />
        </div>

        {/* Rating */}
        <div>
          <label className="block text-charcoal font-semibold mb-3" style={{ fontFamily: "var(--font-body)" }}>
            Rating
          </label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className="transition-transform hover:scale-110"
              >
                <Star
                  size={28}
                  className={star <= rating ? "fill-terracotta text-terracotta" : "text-sand-dark/30"}
                />
              </button>
            ))}
          </div>
        </div>

        {/* Review Text */}
        <div>
          <label className="block text-charcoal font-semibold mb-2" style={{ fontFamily: "var(--font-body)" }}>
            Your Review
          </label>
          <textarea
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            placeholder="Share your experience at Bayshore Retreat... (minimum 10 characters)"
            rows={5}
            className="w-full px-4 py-2 border border-sand-dark/20 rounded-lg focus:outline-none focus:border-terracotta resize-none"
            style={{ fontFamily: "var(--font-body)" }}
          />
          <p className="text-charcoal-light text-xs mt-1">
            {reviewText.length}/10 characters minimum
          </p>
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={submitReviewMutation.isPending}
          className="w-full bg-terracotta text-white hover:bg-terracotta-dark disabled:opacity-50"
        >
          {submitReviewMutation.isPending ? "Submitting..." : "Submit Review"}
        </Button>
      </form>
    </div>
  );
}
