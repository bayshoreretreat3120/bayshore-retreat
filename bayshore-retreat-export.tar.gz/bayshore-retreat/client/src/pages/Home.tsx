/*
 * Bayshore Retreat — Coastal Editorial Design
 * Design: Magazine-style layout with full-bleed photography, warm sand tones,
 * Playfair Display serif headings, terracotta CTAs, editorial asymmetric grids.
 */

import { useState, useEffect, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { ReviewsDisplay } from "./ReviewsDisplay";
import { ReviewSubmissionForm } from "./ReviewSubmissionForm";
import {
  BedDouble,
  Bath,
  Users,
  PawPrint,
  Clock,
  Fence,
  Flame,
  Umbrella,
  Wifi,
  Car,
  Tv,
  WashingMachine,
  Wind,
  MapPin,
  Mail,
  ChevronLeft,
  ChevronRight,
  X,
  Menu,
  UtensilsCrossed,
  Waves,
  TreePine,
  Fish,
  Compass,
  TreePalm,
  Coffee,
  Shell,
  Binoculars,
  Sun,
  Landmark,
} from "lucide-react";

// ─── CONSTANTS ───────────────────────────────────────────────────────────────

// ─── CDN BASE ────────────────────────────────────────────────────────────────
const CDN = "https://d2xsxph8kpxj0f.cloudfront.net/106775624/FuHS7qG5mXXwEMYBgoL5nB";

const LOGO_URL = `${CDN}/bayshore-logo-transparent_34e15653.png`;

// Hero: Covered patio with professional grill and outdoor dining
const HERO_IMG = `${CDN}/Screenshot2026-04-08at10.54.31PM_d7405850.png`;

// About section: Covered patio area
const ABOUT_IMG = `${CDN}/3120MercerRd-05_ce57c34d.webp`;

// Location section background: Neighborhood view
const LOCATION_IMG = `${CDN}/3120MercerRd-40_88f62216.webp`;

// All 35 real property photos for the gallery
const PROPERTY_PHOTOS = [
  `${CDN}/3120MercerRd-01_bca11f52.webp`,
  `${CDN}/3120MercerRd-05_ce57c34d.webp`,
  `${CDN}/3120MercerRd-06_8ebf9dcb.webp`,
  `${CDN}/3120MercerRd-10_804655f5.webp`,
  `${CDN}/3120MercerRd-12_f734b108.webp`,
  `${CDN}/3120MercerRd-13_051e8dcb.webp`,
  `${CDN}/3120MercerRd-14_6786f217.webp`,
  `${CDN}/3120MercerRd-15_7ae38e00.webp`,
  `${CDN}/3120MercerRd-16_e6c8ab40.webp`,
  `${CDN}/3120MercerRd-17_1a514d00.webp`,
  `${CDN}/3120MercerRd-18_fcced5b9.webp`,
  `${CDN}/3120MercerRd-19_2d3c7835.webp`,
  `${CDN}/3120MercerRd-20_96f61e72.webp`,
  `${CDN}/3120MercerRd-21_e5274276.webp`,
  `${CDN}/3120MercerRd-22_25e48187.webp`,
  `${CDN}/3120MercerRd-23_89474ef5.webp`,
  `${CDN}/3120MercerRd-24_4f99f4e2.webp`,
  `${CDN}/3120MercerRd-25_afddc1ed.webp`,
  `${CDN}/3120MercerRd-26_0bcf4725.webp`,
  `${CDN}/3120MercerRd-27_2a9fedb5.webp`,
  `${CDN}/3120MercerRd-28_6ea4dbcf.webp`,
  `${CDN}/3120MercerRd-29_da713f6d.webp`,
  `${CDN}/3120MercerRd-30_07d39f5f.webp`,
  `${CDN}/3120MercerRd-31_607cfae9.webp`,
  `${CDN}/3120MercerRd-32_37763444.webp`,
  `${CDN}/3120MercerRd-33_298af61e.webp`,
  `${CDN}/3120MercerRd-34_f1dbd56b.webp`,
  `${CDN}/3120MercerRd-35_8e257dc5.webp`,
  `${CDN}/3120MercerRd-36_4ceb5ba7.webp`,
  `${CDN}/3120MercerRd-37_ef5a4d1b.webp`,
  `${CDN}/3120MercerRd-38_9e2c91e6.webp`,
  `${CDN}/3120MercerRd-39_220efb53.webp`,
  `${CDN}/3120MercerRd-40_88f62216.webp`,
  `${CDN}/3120MercerRd-41_2100d0c6.webp`,
  `${CDN}/3120MercerRd-42_204b7763.webp`,
];

const BOOKING_LINKS = {
  airbnb: "https://airbnb.com/h/bayshoreretreat3120",
  vrbo: "https://www.expedia.com/Bradenton-Hotels-3BR-Gulf-Coast-Retreat-HUGE-Fenced-Yard-Fire-Pit-Near-Anna-Maria-Island.h127564380.Hotel-Information",
};

const AMENITIES = [
  { icon: BedDouble, label: "3 Queen Beds" },
  { icon: Bath, label: "2 Full Bathrooms" },
  { icon: Users, label: "Sleeps 8 Guests" },
  { icon: PawPrint, label: "Pet Friendly" },
  { icon: Fence, label: "Fenced Yard" },
  { icon: Flame, label: "Fire Pit" },
  { icon: Umbrella, label: "Covered Patio" },
  { icon: Wifi, label: "High-Speed WiFi" },
  { icon: Car, label: "Free Parking" },
  { icon: Tv, label: "Smart TV" },
  { icon: WashingMachine, label: "Washer & Dryer" },
  { icon: Wind, label: "Central A/C" },
];

// ─── ANIMATION VARIANTS ──────────────────────────────────────────────────────

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0, 0, 0.2, 1] as const } },
};

const staggerContainer = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } },
};

// ─── COMPONENTS ──────────────────────────────────────────────────────────────

function AnimatedSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      variants={fadeUp}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function Lightbox({
  photos,
  index,
  onClose,
  onPrev,
  onNext,
}: {
  photos: string[];
  index: number;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
    };
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [onClose, onPrev, onNext]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm"
      onClick={onClose}
    >
      <button
        onClick={(e) => { e.stopPropagation(); onClose(); }}
        className="absolute top-4 right-4 z-50 rounded-full bg-white/10 p-2 text-white hover:bg-white/20 transition-colors"
      >
        <X size={24} />
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); onPrev(); }}
        className="absolute left-4 z-50 rounded-full bg-white/10 p-3 text-white hover:bg-white/20 transition-colors"
      >
        <ChevronLeft size={28} />
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); onNext(); }}
        className="absolute right-4 z-50 rounded-full bg-white/10 p-3 text-white hover:bg-white/20 transition-colors"
      >
        <ChevronRight size={28} />
      </button>
      <div className="max-w-5xl max-h-[85vh] px-16" onClick={(e) => e.stopPropagation()}>
        <img
          src={photos[index]}
          alt={`Photo ${index + 1}`}
          className="max-h-[80vh] w-auto mx-auto rounded-lg object-contain"
        />
        <p className="text-center text-white/80 mt-3 font-body text-sm tracking-wide">
          {index + 1} of {photos.length}
        </p>
      </div>
    </motion.div>
  );
}

// ─── MAIN PAGE ───────────────────────────────────────────────────────────────

export default function Home() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <div className="min-h-screen" style={{ fontFamily: "var(--font-body)" }}>
      {/* ── FLOATING NAV ─────────────────────────────────────────── */}
      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          scrolled
            ? "bg-warm-white/95 backdrop-blur-md shadow-sm py-3"
            : "bg-transparent py-5"
        }`}
      >
        <div className="container flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3">
            <img src={LOGO_URL} alt="Bayshore Retreat" className="h-10 w-auto" />
          </a>
          <div className="hidden md:flex items-center gap-8">
            {["Gallery", "Amenities", "Location", "Local Guide", "Book Now"].map((item) => (
              <a
                key={item}
                href={item === "Local Guide" ? "/local-guide" : `#${item.toLowerCase().replace(" ", "-")}`}
                className={`text-sm font-medium tracking-wide transition-colors ${
                  scrolled
                    ? "text-charcoal hover:text-terracotta"
                    : "text-white/90 hover:text-white"
                }`}
                style={{ fontFamily: "var(--font-body)" }}
              >
                {item}
              </a>
            ))}
          </div>
          <a
            href="#book-now"
            className={`hidden sm:inline-flex items-center px-5 py-2.5 rounded-full text-sm font-semibold transition-all ${
              scrolled
                ? "bg-terracotta text-white hover:bg-terracotta-dark"
                : "bg-white/20 text-white backdrop-blur-sm hover:bg-white/30 border border-white/30"
            }`}
            style={{ fontFamily: "var(--font-body)" }}
          >
            Book Your Stay
          </a>
          <button
            className={`md:hidden p-2 rounded-lg transition-colors ${
              scrolled ? "text-charcoal hover:bg-sand" : "text-white hover:bg-white/10"
            }`}
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`md:hidden px-4 pb-4 ${
              scrolled ? "bg-warm-white/95 backdrop-blur-md" : "bg-black/80 backdrop-blur-md"
            }`}
          >
            <div className="flex flex-col gap-3">
              {["Gallery", "Amenities", "Location", "Local Guide", "Book Now"].map((item) => (
                <a
                  key={item}
                  href={item === "Local Guide" ? "/local-guide" : `#${item.toLowerCase().replace(" ", "-")}`}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-sm font-medium py-2 transition-colors ${
                    scrolled ? "text-charcoal" : "text-white/90"
                  }`}
                  style={{ fontFamily: "var(--font-body)" }}
                >
                  {item}
                </a>
              ))}
              <a
                href="#book-now"
                onClick={() => setMobileMenuOpen(false)}
                className="inline-flex items-center justify-center px-5 py-2.5 bg-terracotta text-white rounded-full text-sm font-semibold mt-1"
                style={{ fontFamily: "var(--font-body)" }}
              >
                Book Your Stay
              </a>
            </div>
          </motion.div>
        )}
      </nav>

      {/* ── HERO ─────────────────────────────────────────────────── */}
      <section id="top" className="relative h-screen min-h-[600px] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="Bayshore Retreat at sunset"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60" />
        </div>
        {/* Guest Favorite Badge - TOP OF HERO */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="absolute top-24 left-0 right-0 z-20 flex justify-start container"
        >
          <div className="inline-flex items-center gap-3 px-5 py-3 bg-terracotta/20 border-2 border-terracotta rounded-xl backdrop-blur-sm">
            <div className="text-terracotta text-4xl">🏆</div>
            <div>
              <p className="text-terracotta font-bold text-lg tracking-wide" style={{ fontFamily: "var(--font-body)" }}>
                GUEST FAVORITE
              </p>
              <p className="text-white text-sm font-semibold" style={{ fontFamily: "var(--font-body)" }}>
                4.8 ★ Airbnb's Most Loved Homes
              </p>
            </div>
          </div>
        </motion.div>
        <div className="relative h-full flex flex-col justify-end pb-16 md:pb-24 container">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
          >
            <p
              className="text-white/80 text-sm md:text-base tracking-[0.25em] uppercase mb-3"
              style={{ fontFamily: "var(--font-body)" }}
            >
              Bradenton, Florida
            </p>
            <h1
              className="text-5xl md:text-7xl lg:text-8xl text-white font-medium leading-[0.95] mb-6"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Bayshore<br />Retreat
            </h1>
            <p
              className="text-white/80 text-lg md:text-xl max-w-lg leading-relaxed mb-8"
              style={{ fontFamily: "var(--font-body)" }}
            >
              A beautifully renovated contemporary home minutes from the Gulf beaches.
              Three bedrooms, fenced yard, fire pit, and room for the whole family.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#book-now"
                className="inline-flex items-center px-8 py-3.5 bg-terracotta text-white rounded-full font-semibold text-base hover:bg-terracotta-dark transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{ fontFamily: "var(--font-body)" }}
              >
                Book Your Stay
              </a>
              <a
                href="#gallery"
                className="inline-flex items-center px-8 py-3.5 bg-white/15 text-white rounded-full font-medium text-base backdrop-blur-sm border border-white/25 hover:bg-white/25 transition-all"
                style={{ fontFamily: "var(--font-body)" }}
              >
                View Photos
              </a>
            </div>
          </motion.div>
        </div>
        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-6 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <div className="w-6 h-10 rounded-full border-2 border-white/40 flex items-start justify-center p-1.5">
            <div className="w-1.5 h-3 bg-white/60 rounded-full" />
          </div>
        </motion.div>
      </section>

      {/* ── QUICK STATS BAR ───────────────────────────────────────── */}
      <section className="bg-charcoal text-white py-8 md:py-10">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 text-center">
            {[
              { number: "3", label: "Bedrooms" },
              { number: "2", label: "Bathrooms" },
              { number: "8", label: "Guests" },
              { number: "3 PM", label: "Check-In" },
            ].map((stat) => (
              <div key={stat.label}>
                <p
                  className="text-4xl md:text-5xl lg:text-6xl text-terracotta-light font-normal"
                  style={{ fontFamily: "var(--font-stat)" }}
                >
                  {stat.number}
                </p>
                <p className="text-white/60 text-sm tracking-[0.15em] uppercase mt-1" style={{ fontFamily: "var(--font-body)" }}>
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── ABOUT / INTRO ────────────────────────────────────────── */}
      <section className="py-20 md:py-28 bg-cream">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-center">
            <AnimatedSection>
              <p className="text-terracotta text-sm tracking-[0.2em] uppercase font-semibold mb-4" style={{ fontFamily: "var(--font-body)" }}>
                Welcome Home
              </p>
              <h2 className="text-3xl md:text-4xl lg:text-5xl text-charcoal leading-tight mb-6" style={{ fontFamily: "var(--font-display)" }}>
                Your Family's<br />
                <em className="text-terracotta">Perfect Getaway</em>
              </h2>
              <p className="text-charcoal-light text-lg leading-relaxed mb-6" style={{ fontFamily: "var(--font-body)" }}>
                Nestled in the heart of Bradenton's Bayshore Gardens neighborhood,
                this beautifully renovated 3-bedroom contemporary home offers the ideal
                blend of comfort and convenience. Just 9 miles from Bradenton Beach
                and 10 miles from downtown Sarasota, you'll be close to everything
                while enjoying a peaceful retreat.
              </p>
              <p className="text-charcoal-light text-lg leading-relaxed" style={{ fontFamily: "var(--font-body)" }}>
                Gather around the fire pit under the stars, let the kids and pets
                play in the fenced yard, or unwind on the covered patio. With
                three queen beds, there's room for the whole crew.
              </p>
            </AnimatedSection>
            <AnimatedSection>
              <div className="relative">
                <img
                  src={ABOUT_IMG}
                  alt="Fire pit and backyard area"
                  className="rounded-lg shadow-xl w-full aspect-[4/3] object-cover"
                />
                <div className="absolute -bottom-6 -left-6 bg-terracotta text-white px-6 py-4 rounded-lg shadow-lg hidden md:block">
                  <p className="text-2xl font-bold" style={{ fontFamily: "var(--font-stat)" }}>4.96</p>
                  <p className="text-sm text-white/80" style={{ fontFamily: "var(--font-body)" }}>Guest Rating</p>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* ── PHOTO GALLERY ────────────────────────────────────────── */}
      <section id="gallery" className="py-20 md:py-28 bg-sand-light">
        <div className="container">
          <AnimatedSection className="text-center mb-14">
            <p className="text-terracotta text-sm tracking-[0.2em] uppercase font-semibold mb-4" style={{ fontFamily: "var(--font-body)" }}>
              Take a Tour
            </p>
            <h2 className="text-3xl md:text-4xl lg:text-5xl text-charcoal" style={{ fontFamily: "var(--font-display)" }}>
              Inside the Retreat
            </h2>
          </AnimatedSection>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4"
          >
            {PROPERTY_PHOTOS.map((photo, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                className={`relative group cursor-pointer overflow-hidden rounded-lg ${
                  i === 0 ? "col-span-2 row-span-2" : ""
                }`}
                onClick={() => setLightboxIndex(i)}
              >
                <img
                  src={photo}
                  alt={`Photo ${i + 1}`}
                  className={`w-full object-cover transition-transform duration-500 group-hover:scale-105 ${
                    i === 0 ? "aspect-square" : "aspect-[4/3]"
                  }`}
                  loading="lazy"
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── AMENITIES ────────────────────────────────────────────── */}
      <section id="amenities" className="py-20 md:py-28 bg-cream">
        <div className="container">
          <AnimatedSection className="text-center mb-14">
            <p className="text-terracotta text-sm tracking-[0.2em] uppercase font-semibold mb-4" style={{ fontFamily: "var(--font-body)" }}>
              Everything You Need
            </p>
            <h2 className="text-3xl md:text-4xl lg:text-5xl text-charcoal" style={{ fontFamily: "var(--font-display)" }}>
              Home Amenities
            </h2>
          </AnimatedSection>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 max-w-4xl mx-auto"
          >
            {AMENITIES.map((amenity, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                className="flex flex-col items-center text-center p-6 bg-warm-white rounded-lg border border-sand-dark/20 hover:shadow-md hover:border-terracotta/30 transition-all duration-300"
              >
                <amenity.icon
                  size={28}
                  className="text-terracotta mb-3"
                  strokeWidth={1.5}
                />
                <p className="text-charcoal text-sm font-medium" style={{ fontFamily: "var(--font-body)" }}>
                  {amenity.label}
                </p>
              </motion.div>
            ))}
          </motion.div>

          {/* Sleeping arrangements */}
          <AnimatedSection className="mt-16">
            <div className="max-w-3xl mx-auto bg-warm-white rounded-xl border border-sand-dark/20 p-8 md:p-10">
              <h3 className="text-2xl text-charcoal mb-6 text-center" style={{ fontFamily: "var(--font-display)" }}>
                Sleeping Arrangements
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { room: "Primary Bedroom", bed: "Queen Bed", icon: "🛏️" },
                  { room: "Bedroom 2", bed: "Queen Bed", icon: "🛏️" },
                  { room: "Bedroom 3", bed: "Queen Bed", icon: "🛏️" },
                ].map((room) => (
                  <div key={room.room} className="text-center p-4 rounded-lg bg-sand-light/50">
                    <p className="text-3xl mb-2">{room.icon}</p>
                    <p className="text-charcoal font-semibold text-base" style={{ fontFamily: "var(--font-body)" }}>
                      {room.room}
                    </p>
                    <p className="text-charcoal-light text-sm mt-1" style={{ fontFamily: "var(--font-body)" }}>
                      {room.bed}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* ── LOCATION BAND ────────────────────────────────────────── */}
      <section id="location" className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={LOCATION_IMG}
            alt="Aerial view of the neighborhood"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-charcoal/70" />
        </div>
        <div className="relative container">
          <AnimatedSection className="text-center max-w-3xl mx-auto">
            <p className="text-terracotta-light text-sm tracking-[0.2em] uppercase font-semibold mb-4" style={{ fontFamily: "var(--font-body)" }}>
              Prime Location
            </p>
            <h2 className="text-3xl md:text-4xl lg:text-5xl text-white mb-8" style={{ fontFamily: "var(--font-display)" }}>
              Minutes from Paradise
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { place: "Bradenton Beach", time: "9 miles" },
                { place: "Anna Maria Island", time: "12 miles" },
                { place: "Downtown Sarasota", time: "10 miles" },
                { place: "SRQ Airport", time: "15 min" },
              ].map((loc) => (
                <div key={loc.place} className="bg-white/10 backdrop-blur-sm rounded-lg p-5 border border-white/10">
                  <MapPin size={20} className="text-terracotta-light mx-auto mb-2" />
                  <p className="text-white font-semibold text-base" style={{ fontFamily: "var(--font-body)" }}>
                    {loc.place}
                  </p>
                  <p className="text-white/60 text-sm mt-1" style={{ fontFamily: "var(--font-body)" }}>
                    {loc.time}
                  </p>
                </div>
              ))}
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* ── LOCAL GUIDE ───────────────────────────────────────── */}
      <section className="py-20 md:py-28 bg-warm-white">
        <div className="container">
          <AnimatedSection className="text-center mb-14">
            <p className="text-terracotta text-sm tracking-[0.2em] uppercase font-semibold mb-4" style={{ fontFamily: "var(--font-body)" }}>
              Explore the Area
            </p>
            <h2 className="text-3xl md:text-4xl lg:text-5xl text-charcoal" style={{ fontFamily: "var(--font-display)" }}>
              Local Favorites
            </h2>
            <p className="text-charcoal-light text-lg mt-4 max-w-2xl mx-auto" style={{ fontFamily: "var(--font-body)" }}>
              From fresh Gulf seafood to pristine barrier island beaches, here are our top picks just minutes from the retreat.
            </p>
          </AnimatedSection>

          {/* Dining */}
          <AnimatedSection className="mb-16">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-full bg-terracotta/10 flex items-center justify-center">
                <UtensilsCrossed size={20} className="text-terracotta" />
              </div>
              <h3 className="text-2xl text-charcoal" style={{ fontFamily: "var(--font-display)" }}>Dining</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {[
                {
                  name: "Star Fish Co",
                  desc: "Fresh-off-the-boat seafood in the historic Cortez fishing village. Outdoor waterfront seating.",
                  distance: "7 mi",
                  icon: Fish,
                },
                {
                  name: "Pier 22",
                  desc: "Upscale waterfront dining on the Manatee River. Seafood, steaks, and craft cocktails downtown.",
                  distance: "5 mi",
                  icon: Waves,
                },
                {
                  name: "Beach House Restaurant",
                  desc: "Toes-in-the-sand beachfront dining on Anna Maria Island with stunning Gulf sunset views.",
                  distance: "10 mi",
                  icon: Sun,
                },
                {
                  name: "Mean Deans Local Kitchen",
                  desc: "Voted Top 3 Best Restaurant in Bradenton. Comfort food with a creative twist. Local favorite.",
                  distance: "2 mi",
                  icon: Coffee,
                },
              ].map((spot) => (
                <div
                  key={spot.name}
                  className="bg-cream rounded-xl p-6 border border-sand-dark/10 hover:shadow-lg transition-shadow duration-300 group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <spot.icon size={22} className="text-terracotta" strokeWidth={1.5} />
                    <span className="text-xs text-charcoal-light bg-sand/60 px-2.5 py-1 rounded-full" style={{ fontFamily: "var(--font-body)" }}>
                      {spot.distance}
                    </span>
                  </div>
                  <h4 className="text-lg text-charcoal font-semibold mb-2" style={{ fontFamily: "var(--font-body)" }}>
                    {spot.name}
                  </h4>
                  <p className="text-charcoal-light text-sm leading-relaxed" style={{ fontFamily: "var(--font-body)" }}>
                    {spot.desc}
                  </p>
                </div>
              ))}
            </div>
          </AnimatedSection>

          {/* Beaches */}
          <AnimatedSection className="mb-16">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-full bg-terracotta/10 flex items-center justify-center">
                <Waves size={20} className="text-terracotta" />
              </div>
              <h3 className="text-2xl text-charcoal" style={{ fontFamily: "var(--font-display)" }}>Beaches</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {[
                {
                  name: "Coquina Beach",
                  desc: "Calm turquoise waters, sugary white sand, and a beachside cafe. Great for families and shark tooth hunting.",
                  distance: "11 mi",
                  icon: Shell,
                },
                {
                  name: "Manatee Beach",
                  desc: "Full-amenity public beach with volleyball, playground, picnic areas, and a casual beachside grill.",
                  distance: "12 mi",
                  icon: Sun,
                },
                {
                  name: "Palma Sola Causeway",
                  desc: "Calm bay waters perfect for paddleboarding and kayaking. Dog-friendly with beautiful sunset views.",
                  distance: "7 mi",
                  icon: Compass,
                },
                {
                  name: "Bean Point",
                  desc: "The secluded northern tip of Anna Maria Island. Pristine sand, dolphins, and spectacular sunsets.",
                  distance: "14 mi",
                  icon: Binoculars,
                },
              ].map((spot) => (
                <div
                  key={spot.name}
                  className="bg-cream rounded-xl p-6 border border-sand-dark/10 hover:shadow-lg transition-shadow duration-300 group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <spot.icon size={22} className="text-terracotta" strokeWidth={1.5} />
                    <span className="text-xs text-charcoal-light bg-sand/60 px-2.5 py-1 rounded-full" style={{ fontFamily: "var(--font-body)" }}>
                      {spot.distance}
                    </span>
                  </div>
                  <h4 className="text-lg text-charcoal font-semibold mb-2" style={{ fontFamily: "var(--font-body)" }}>
                    {spot.name}
                  </h4>
                  <p className="text-charcoal-light text-sm leading-relaxed" style={{ fontFamily: "var(--font-body)" }}>
                    {spot.desc}
                  </p>
                </div>
              ))}
            </div>
          </AnimatedSection>

          {/* Activities */}
          <AnimatedSection>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-full bg-terracotta/10 flex items-center justify-center">
                <Compass size={20} className="text-terracotta" />
              </div>
              <h3 className="text-2xl text-charcoal" style={{ fontFamily: "var(--font-display)" }}>Activities</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {[
                {
                  name: "Robinson Preserve",
                  desc: "682-acre nature preserve with kayak trails, hiking paths, and a panoramic observation tower.",
                  distance: "8 mi",
                  icon: TreePine,
                },
                {
                  name: "Bradenton Riverwalk",
                  desc: "1.5-mile waterfront promenade with splash pads, playgrounds, public art, and live events.",
                  distance: "5 mi",
                  icon: Landmark,
                },
                {
                  name: "De Soto National Memorial",
                  desc: "National park with nature trails, living history programs, and mangrove-lined kayak routes.",
                  distance: "6 mi",
                  icon: Binoculars,
                },
                {
                  name: "Cortez Fishing Village",
                  desc: "Historic working fishing village. Fresh seafood markets, boat tours, and old Florida charm.",
                  distance: "7 mi",
                  icon: Fish,
                },
              ].map((spot) => (
                <div
                  key={spot.name}
                  className="bg-cream rounded-xl p-6 border border-sand-dark/10 hover:shadow-lg transition-shadow duration-300 group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <spot.icon size={22} className="text-terracotta" strokeWidth={1.5} />
                    <span className="text-xs text-charcoal-light bg-sand/60 px-2.5 py-1 rounded-full" style={{ fontFamily: "var(--font-body)" }}>
                      {spot.distance}
                    </span>
                  </div>
                  <h4 className="text-lg text-charcoal font-semibold mb-2" style={{ fontFamily: "var(--font-body)" }}>
                    {spot.name}
                  </h4>
                  <p className="text-charcoal-light text-sm leading-relaxed" style={{ fontFamily: "var(--font-body)" }}>
                    {spot.desc}
                  </p>
                </div>
              ))}
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* ── BOOK NOW ─────────────────────────────────────────────── */}
      <section id="book-now" className="py-20 md:py-28 bg-cream">
        <div className="container">
          <AnimatedSection className="text-center max-w-3xl mx-auto">
            <p className="text-terracotta text-sm tracking-[0.2em] uppercase font-semibold mb-4" style={{ fontFamily: "var(--font-body)" }}>
              Ready to Visit?
            </p>
            <h2 className="text-3xl md:text-4xl lg:text-5xl text-charcoal mb-4" style={{ fontFamily: "var(--font-display)" }}>
              Book Your Stay
            </h2>
            <p className="text-charcoal-light text-lg mb-12 max-w-xl mx-auto" style={{ fontFamily: "var(--font-body)" }}>
              Choose your preferred booking platform below. We're listed on all
              major travel sites for your convenience.
            </p>

            <div className="flex flex-wrap justify-center gap-6">
              {/* Airbnb */}
              <a
                href={BOOKING_LINKS.airbnb}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col items-center p-8 bg-warm-white rounded-xl border border-sand-dark/20 hover:border-[#FF5A5F]/40 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <svg className="w-10 h-10 mb-4" viewBox="0 0 24 24" fill="none">
                  <path d="M12.001 18.575c-.467-.8-1.2-2.133-1.867-3.4-.8-1.533-1.6-3.133-1.6-4.375 0-1.933 1.533-3.467 3.467-3.467s3.467 1.533 3.467 3.467c0 1.242-.8 2.842-1.6 4.375-.667 1.267-1.4 2.6-1.867 3.4zm0 2.425c.6-1.067 4.8-8.267 4.8-10.2C16.801 7.6 14.801 5.6 12 5.6S7.2 7.6 7.2 10.8c0 1.933 4.2 9.133 4.8 10.2z" fill="#FF5A5F"/>
                  <circle cx="12" cy="10.8" r="1.6" fill="#FF5A5F"/>
                </svg>
                <p className="text-charcoal font-bold text-lg group-hover:text-[#FF5A5F] transition-colors" style={{ fontFamily: "var(--font-body)" }}>
                  Airbnb
                </p>
                <p className="text-charcoal-light text-xs mt-1" style={{ fontFamily: "var(--font-body)" }}>
                  View Listing
                </p>
              </a>

              {/* VRBO */}
              <a
                href={BOOKING_LINKS.vrbo}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col items-center p-8 bg-warm-white rounded-xl border border-sand-dark/20 hover:border-[#003580]/40 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <svg className="w-10 h-10 mb-4" viewBox="0 0 100 100" fill="none">
                  <rect x="10" y="20" width="80" height="60" rx="4" stroke="#003580" strokeWidth="3" fill="none"/>
                  <path d="M20 35 L80 35 M20 50 L80 50 M20 65 L60 65" stroke="#003580" strokeWidth="2"/>
                </svg>
                <p className="text-charcoal font-bold text-lg group-hover:text-[#003580] transition-colors" style={{ fontFamily: "var(--font-body)" }}>
                  VRBO
                </p>
                <p className="text-charcoal-light text-xs mt-1" style={{ fontFamily: "var(--font-body)" }}>
                  View Listing
                </p>
              </a>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* ── GUEST REVIEWS ───────────────────────────────────────── */}
      <section id="reviews" className="py-20 md:py-28 bg-cream">
        <div className="container">
          <AnimatedSection className="text-center mb-14">
            <p className="text-terracotta text-sm tracking-[0.2em] uppercase font-semibold mb-4" style={{ fontFamily: "var(--font-body)" }}>
              Guest Experiences
            </p>
            <h2 className="text-3xl md:text-4xl lg:text-5xl text-charcoal mb-6" style={{ fontFamily: "var(--font-display)" }}>
              What Our Guests Say
            </h2>
            
            {/* Rating Badge */}
            <div className="flex flex-col items-center gap-3 mb-8">
              <div className="flex items-center gap-2">
                <span className="text-4xl font-bold text-charcoal">4.75</span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg key={star} className="w-6 h-6 fill-terracotta" viewBox="0 0 24 24">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                    </svg>
                  ))}
                </div>
              </div>
              <p className="text-lg font-semibold text-charcoal" style={{ fontFamily: "var(--font-body)" }}>Guest favorite</p>
              <p className="text-sm text-charcoal-light" style={{ fontFamily: "var(--font-body)" }}>One of the most loved homes on Airbnb, according to guests</p>
            </div>
            
            <p className="text-charcoal-light text-lg max-w-2xl mx-auto" style={{ fontFamily: "var(--font-body)" }}>
              Read authentic reviews from guests who have stayed at Bayshore Retreat.
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <AnimatedSection>
              <h3 className="text-2xl text-charcoal mb-6" style={{ fontFamily: "var(--font-display)" }}>
                Recent Reviews
              </h3>
              <ReviewsDisplay />
            </AnimatedSection>

            <AnimatedSection>
              <h3 className="text-2xl text-charcoal mb-6" style={{ fontFamily: "var(--font-display)" }}>
                Share Your Review
              </h3>
              <ReviewSubmissionForm />
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* ── HOUSE RULES QUICK GLANCE ─────────────────────────────── */}
      <section className="py-16 md:py-20 bg-sand-light">
        <div className="container max-w-3xl">
          <AnimatedSection>
            <h3 className="text-2xl md:text-3xl text-charcoal text-center mb-8" style={{ fontFamily: "var(--font-display)" }}>
              Good to Know
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { icon: Clock, text: "Check-in: 3:00 PM" },
                { icon: Clock, text: "Check-out: 10:00 AM" },
                { icon: PawPrint, text: "Pets welcome (fee may apply)" },
                { icon: Users, text: "Max 8 guests" },
                { icon: Car, text: "Free driveway parking" },
                { icon: Fence, text: "Fully fenced backyard" },
              ].map((rule, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 p-4 bg-warm-white rounded-lg border border-sand-dark/15"
                >
                  <rule.icon size={20} className="text-terracotta shrink-0" strokeWidth={1.5} />
                  <p className="text-charcoal text-sm font-medium" style={{ fontFamily: "var(--font-body)" }}>
                    {rule.text}
                  </p>
                </div>
              ))}
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* ── FOOTER ───────────────────────────────────────────────── */}
      <footer className="bg-charcoal text-white py-12 md:py-16">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 items-start">
            <div>
              <img src={LOGO_URL} alt="Bayshore Retreat" className="h-12 w-auto mb-4" style={{ filter: "brightness(0) invert(1)" }} />
              <p className="text-white/50 text-sm leading-relaxed" style={{ fontFamily: "var(--font-body)" }}>
                A vacation rental in Bradenton, FL.<br />
                3120 Mercer Rd, Bradenton, FL 34207
              </p>
            </div>
            <div className="text-center">
              <h4 className="text-white/80 text-sm tracking-[0.15em] uppercase mb-4" style={{ fontFamily: "var(--font-body)" }}>
                Quick Links
              </h4>
              <div className="flex flex-col gap-2">
                {["Gallery", "Amenities", "Location", "Local Guide", "Book Now"].map((link) => (
                  <a
                    key={link}
                    href={link === "Local Guide" ? "/local-guide" : `#${link.toLowerCase().replace(" ", "-")}`}
                    className="text-white/50 text-sm hover:text-terracotta-light transition-colors"
                    style={{ fontFamily: "var(--font-body)" }}
                  >
                    {link}
                  </a>
                ))}
              </div>
            </div>
            <div className="md:text-right">
              <h4 className="text-white/80 text-sm tracking-[0.15em] uppercase mb-4" style={{ fontFamily: "var(--font-body)" }}>
                Connect
              </h4>
              <div className="flex flex-col gap-3">
                <a
                  href="mailto:askrivas@gmail.com"
                  className="inline-flex items-center gap-2 text-white/50 text-sm hover:text-terracotta-light transition-colors"
                  style={{ fontFamily: "var(--font-body)" }}
                >
                  <Mail size={14} />
                  askrivas@gmail.com
                </a>
                <a
                  href="https://www.facebook.com/profile.php?id=61590421445947"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-white/50 text-sm hover:text-terracotta-light transition-colors"
                  style={{ fontFamily: "var(--font-body)" }}
                >
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                  Follow on Facebook
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-white/10 mt-10 pt-8 text-center">
            <p className="text-white/30 text-xs" style={{ fontFamily: "var(--font-body)" }}>
              &copy; {new Date().getFullYear()} Bayshore Retreat. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* ── LIGHTBOX ─────────────────────────────────────────────── */}
      {lightboxIndex !== null && (
        <Lightbox
          photos={PROPERTY_PHOTOS}
          index={lightboxIndex}
          onClose={() => setLightboxIndex(null)}
          onPrev={() =>
            setLightboxIndex((prev) =>
              prev !== null ? (prev - 1 + PROPERTY_PHOTOS.length) % PROPERTY_PHOTOS.length : 0
            )
          }
          onNext={() =>
            setLightboxIndex((prev) =>
              prev !== null ? (prev + 1) % PROPERTY_PHOTOS.length : 0
            )
          }
        />
      )}
    </div>
  );
}
