import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, CheckCircle, XCircle, Star } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

export default function ReviewsManagement() {
  const { user } = useAuth();
  const [selectedReviewId, setSelectedReviewId] = useState<number | null>(null);

  // Fetch pending reviews
  const { data: pendingReviews, isLoading: isLoadingPending, refetch: refetchPending } = trpc.reviews.pending.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  // Mutations
  const approveMutation = trpc.reviews.approve.useMutation({
    onSuccess: () => {
      refetchPending();
      setSelectedReviewId(null);
    },
  });

  const rejectMutation = trpc.reviews.reject.useMutation({
    onSuccess: () => {
      refetchPending();
      setSelectedReviewId(null);
    },
  });

  if (user?.role !== "admin") {
    return (
      <div className="p-6 text-center">
        <p className="text-charcoal-light">You do not have permission to manage reviews.</p>
      </div>
    );
  }

  if (isLoadingPending) {
    return (
      <div className="p-6 flex items-center justify-center gap-2">
        <Loader2 size={20} className="animate-spin text-terracotta" />
        <span className="text-charcoal-light">Loading pending reviews...</span>
      </div>
    );
  }

  const pendingCount = pendingReviews?.length || 0;

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-charcoal mb-2">Reviews Management</h2>
        <p className="text-charcoal-light">
          {pendingCount === 0
            ? "No pending reviews to moderate."
            : `${pendingCount} review${pendingCount !== 1 ? "s" : ""} awaiting approval`}
        </p>
      </div>

      {pendingReviews && pendingReviews.length > 0 ? (
        <div className="space-y-4">
          {pendingReviews.map((review) => (
            <Card key={review.id} className="p-4 border border-sand-dark/20">
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-charcoal">{review.guestName}</h3>
                    <p className="text-xs text-charcoal-light">
                      {new Date(review.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
                      />
                    ))}
                  </div>
                </div>

                {/* Review Text */}
                <p className="text-charcoal text-sm leading-relaxed">{review.reviewText}</p>

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    variant="default"
                    className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                    onClick={() => approveMutation.mutate({ reviewId: review.id })}
                    disabled={approveMutation.isPending || rejectMutation.isPending}
                  >
                    {approveMutation.isPending ? (
                      <Loader2 size={14} className="animate-spin" />
                    ) : (
                      <CheckCircle size={14} />
                    )}
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-red-300 text-red-600 hover:bg-red-50 flex items-center gap-2"
                    onClick={() => rejectMutation.mutate({ reviewId: review.id })}
                    disabled={approveMutation.isPending || rejectMutation.isPending}
                  >
                    {rejectMutation.isPending ? (
                      <Loader2 size={14} className="animate-spin" />
                    ) : (
                      <XCircle size={14} />
                    )}
                    Reject
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-8 text-center border border-sand-dark/10">
          <p className="text-charcoal-light">All reviews have been moderated!</p>
        </Card>
      )}
    </div>
  );
}
