import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, CheckCircle, XCircle, Star, LogOut } from "lucide-react";

const ADMIN_EMAILS = ["realtor@jaywaddell.com", "tourintpa@gmail.com"];

export default function AdminReviews() {
  const [adminEmail, setAdminEmail] = useState<string>("");
  const [isVerified, setIsVerified] = useState(false);
  const [emailInput, setEmailInput] = useState("");
  const [error, setError] = useState("");

  // Fetch pending reviews
  const { data: pendingReviews, isLoading: isLoadingPending, refetch: refetchPending } = trpc.reviews.pending.useQuery(undefined, {
    enabled: isVerified,
  });

  // Mutations
  const approveMutation = trpc.reviews.approve.useMutation({
    onSuccess: () => {
      refetchPending();
    },
  });

  const rejectMutation = trpc.reviews.reject.useMutation({
    onSuccess: () => {
      refetchPending();
    },
  });

  // Check if email is already verified from localStorage
  useEffect(() => {
    const storedEmail = localStorage.getItem("admin-email");
    if (storedEmail && ADMIN_EMAILS.includes(storedEmail)) {
      setAdminEmail(storedEmail);
      setIsVerified(true);
    }
  }, []);

  const handleVerify = () => {
    setError("");
    if (!emailInput.trim()) {
      setError("Please enter your email address");
      return;
    }

    if (!ADMIN_EMAILS.includes(emailInput.toLowerCase())) {
      setError("This email is not authorized as an admin");
      return;
    }

    setAdminEmail(emailInput.toLowerCase());
    localStorage.setItem("admin-email", emailInput.toLowerCase());
    setIsVerified(true);
    setEmailInput("");
  };

  const handleLogout = () => {
    setIsVerified(false);
    setAdminEmail("");
    localStorage.removeItem("admin-email");
  };

  if (!isVerified) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-cream to-sand flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 border-sand-dark/20">
          <h1 className="text-3xl font-bold text-charcoal mb-2" style={{ fontFamily: "var(--font-display)" }}>
            Reviews Admin
          </h1>
          <p className="text-charcoal-light mb-6" style={{ fontFamily: "var(--font-body)" }}>
            Enter your Manus admin email to access the reviews dashboard
          </p>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-charcoal mb-2">
                Admin Email
              </label>
              <input
                type="email"
                value={emailInput}
                onChange={(e) => {
                  setEmailInput(e.target.value);
                  setError("");
                }}
                onKeyPress={(e) => e.key === "Enter" && handleVerify()}
                placeholder="realtor@jaywaddell.com"
                className="w-full px-4 py-2 border border-sand-dark/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-terracotta"
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                {error}
              </div>
            )}

            <Button
              onClick={handleVerify}
              className="w-full bg-terracotta hover:bg-terracotta-dark text-white"
            >
              Access Dashboard
            </Button>
          </div>

          <p className="text-xs text-charcoal-light text-center mt-6">
            Authorized emails: realtor@jaywaddell.com, tourintpa@gmail.com
          </p>
        </Card>
      </div>
    );
  }

  if (isLoadingPending) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 size={32} className="animate-spin text-terracotta" />
          <p className="text-charcoal-light">Loading pending reviews...</p>
        </div>
      </div>
    );
  }

  const pendingCount = pendingReviews?.length || 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream to-sand p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-charcoal" style={{ fontFamily: "var(--font-display)" }}>
              Reviews Dashboard
            </h1>
            <p className="text-charcoal-light mt-1" style={{ fontFamily: "var(--font-body)" }}>
              Logged in as: <span className="font-semibold text-charcoal">{adminEmail}</span>
            </p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="flex items-center gap-2"
          >
            <LogOut size={16} />
            Logout
          </Button>
        </div>

        {/* Status */}
        <div className="mb-8 p-4 bg-warm-white rounded-lg border border-sand-dark/20">
          <p className="text-charcoal-light" style={{ fontFamily: "var(--font-body)" }}>
            {pendingCount === 0
              ? "✓ All reviews have been moderated!"
              : `${pendingCount} review${pendingCount !== 1 ? "s" : ""} awaiting approval`}
          </p>
        </div>

        {/* Reviews List */}
        {pendingReviews && pendingReviews.length > 0 ? (
          <div className="space-y-4">
            {pendingReviews.map((review) => (
              <Card key={review.id} className="p-6 border border-sand-dark/20 hover:shadow-lg transition-shadow">
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-charcoal" style={{ fontFamily: "var(--font-body)" }}>
                        {review.guestName}
                      </h3>
                      <p className="text-xs text-charcoal-light mt-1">
                        {new Date(review.createdAt).toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          size={18}
                          className={
                            i < review.rating
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }
                        />
                      ))}
                    </div>
                  </div>

                  {/* Review Text */}
                  <p className="text-charcoal leading-relaxed" style={{ fontFamily: "var(--font-body)" }}>
                    {review.reviewText}
                  </p>

                  {/* Actions */}
                  <div className="flex gap-3 pt-2">
                    <Button
                      onClick={() => approveMutation.mutate({ reviewId: review.id })}
                      disabled={approveMutation.isPending || rejectMutation.isPending}
                      className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white"
                    >
                      {approveMutation.isPending ? (
                        <Loader2 size={16} className="animate-spin" />
                      ) : (
                        <CheckCircle size={16} />
                      )}
                      Approve
                    </Button>
                    <Button
                      onClick={() => rejectMutation.mutate({ reviewId: review.id })}
                      disabled={approveMutation.isPending || rejectMutation.isPending}
                      variant="outline"
                      className="flex items-center gap-2 border-red-300 text-red-600 hover:bg-red-50"
                    >
                      {rejectMutation.isPending ? (
                        <Loader2 size={16} className="animate-spin" />
                      ) : (
                        <XCircle size={16} />
                      )}
                      Reject
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center border border-sand-dark/10">
            <p className="text-charcoal-light text-lg" style={{ fontFamily: "var(--font-body)" }}>
              All reviews have been moderated! 🎉
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
