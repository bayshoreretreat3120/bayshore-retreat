import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Star, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";

export function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [actionInProgress, setActionInProgress] = useState<number | null>(null);

  const { data: pendingReviews, refetch } = trpc.reviews.pending.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const approveMutation = trpc.reviews.approve.useMutation();
  const rejectMutation = trpc.reviews.reject.useMutation();

  const handleApprove = async (reviewId: number) => {
    setActionInProgress(reviewId);
    try {
      await approveMutation.mutateAsync({ reviewId });
      refetch();
    } finally {
      setActionInProgress(null);
    }
  };

  const handleReject = async (reviewId: number) => {
    setActionInProgress(reviewId);
    try {
      await rejectMutation.mutateAsync({ reviewId });
      refetch();
    } finally {
      setActionInProgress(null);
    }
  };

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="text-center py-12">
        <p className="text-charcoal-light">You do not have permission to access this page.</p>
      </div>
    );
  }

  if (!pendingReviews) {
    return (
      <div className="text-center py-12">
        <p className="text-charcoal-light">Loading...</p>
      </div>
    );
  }

  if (pendingReviews.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-charcoal-light">No pending reviews to moderate.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-3xl text-charcoal" style={{ fontFamily: "var(--font-display)" }}>
        Pending Reviews ({pendingReviews.length})
      </h2>

      {pendingReviews.map((review) => (
        <div
          key={review.id}
          className="bg-warm-white rounded-lg border border-sand-dark/20 p-6"
        >
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-charcoal font-semibold text-lg" style={{ fontFamily: "var(--font-body)" }}>
                {review.guestName}
              </p>
              <p className="text-charcoal-light text-sm mt-1">
                {new Date(review.createdAt).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  size={18}
                  className={
                    star <= review.rating
                      ? "fill-terracotta text-terracotta"
                      : "text-sand-dark/20"
                  }
                />
              ))}
            </div>
          </div>

          <p className="text-charcoal-light text-sm leading-relaxed mb-6" style={{ fontFamily: "var(--font-body)" }}>
            {review.reviewText}
          </p>

          <div className="flex gap-3">
            <Button
              onClick={() => handleApprove(review.id)}
              disabled={actionInProgress === review.id}
              className="flex items-center gap-2 bg-green-600 text-white hover:bg-green-700 disabled:opacity-50"
            >
              <CheckCircle size={16} />
              Approve
            </Button>
            <Button
              onClick={() => handleReject(review.id)}
              disabled={actionInProgress === review.id}
              className="flex items-center gap-2 bg-red-600 text-white hover:bg-red-700 disabled:opacity-50"
            >
              <XCircle size={16} />
              Reject
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
