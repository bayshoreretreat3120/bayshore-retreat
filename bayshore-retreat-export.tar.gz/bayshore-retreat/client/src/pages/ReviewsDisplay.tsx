import { trpc } from "@/lib/trpc";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";
import { useState, useEffect } from "react";

export function ReviewsDisplay() {
  const { data: reviews, isLoading } = trpc.reviews.approved.useQuery();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  // Auto-advance carousel every 6 seconds
  useEffect(() => {
    if (!autoPlay || !reviews || reviews.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % reviews.length);
    }, 6000);

    return () => clearInterval(interval);
  }, [autoPlay, reviews]);

  const handlePrev = () => {
    if (!reviews) return;
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
    setAutoPlay(false);
  };

  const handleNext = () => {
    if (!reviews) return;
    setCurrentIndex((prev) => (prev + 1) % reviews.length);
    setAutoPlay(false);
  };

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <p className="text-charcoal-light">Loading reviews...</p>
      </div>
    );
  }

  if (!reviews || reviews.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-charcoal-light">No reviews yet. Be the first to share your experience!</p>
      </div>
    );
  }

  const currentReview = reviews[currentIndex];
  const reviewCount = reviews.length;

  return (
    <div className="space-y-4">
      {/* Review Count Badge */}
      <div className="inline-block px-4 py-2 bg-terracotta/10 border border-terracotta/30 rounded-full">
        <p className="text-sm font-semibold text-terracotta" style={{ fontFamily: "var(--font-body)" }}>
          ★ {reviewCount} Verified Review{reviewCount !== 1 ? "s" : ""}
        </p>
      </div>

      {/* Carousel Container */}
      <div className="relative">
        {/* Current Review */}
        <div
          key={currentReview.id}
          className="bg-warm-white rounded-lg border border-sand-dark/20 p-6 hover:shadow-md transition-shadow"
        >
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-charcoal font-semibold" style={{ fontFamily: "var(--font-body)" }}>
                {currentReview.guestName}
              </p>
              <p className="text-charcoal-light text-xs mt-1">
                {new Date(currentReview.createdAt).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  size={16}
                  className={
                    star <= currentReview.rating
                      ? "fill-terracotta text-terracotta"
                      : "text-sand-dark/20"
                  }
                />
              ))}
            </div>
          </div>
          <p className="text-charcoal-light text-sm leading-relaxed" style={{ fontFamily: "var(--font-body)" }}>
            {currentReview.reviewText}
          </p>
        </div>

        {/* Navigation Arrows - Only show if more than 1 review */}
        {reviews.length > 1 && (
          <>
            <button
              onClick={handlePrev}
              onMouseEnter={() => setAutoPlay(false)}
              onMouseLeave={() => setAutoPlay(true)}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-14 p-2 rounded-full bg-terracotta/10 hover:bg-terracotta/20 text-terracotta transition-colors"
              aria-label="Previous review"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={handleNext}
              onMouseEnter={() => setAutoPlay(false)}
              onMouseLeave={() => setAutoPlay(true)}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-14 p-2 rounded-full bg-terracotta/10 hover:bg-terracotta/20 text-terracotta transition-colors"
              aria-label="Next review"
            >
              <ChevronRight size={20} />
            </button>
          </>
        )}
      </div>

      {/* Carousel Indicators - Only show if more than 1 review */}
      {reviews.length > 1 && (
        <div className="flex justify-center gap-2 mt-4">
          {reviews.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setCurrentIndex(index);
                setAutoPlay(false);
              }}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentIndex
                  ? "bg-terracotta w-6"
                  : "bg-sand-dark/30 hover:bg-sand-dark/50"
              }`}
              aria-label={`Go to review ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
