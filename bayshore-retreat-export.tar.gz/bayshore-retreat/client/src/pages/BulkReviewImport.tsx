import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Upload, CheckCircle, AlertCircle } from "lucide-react";

interface ParsedReview {
  guestName: string;
  rating: number;
  reviewText: string;
}

export function BulkReviewImport() {
  const [textInput, setTextInput] = useState("");
  const [parsedReviews, setParsedReviews] = useState<ParsedReview[]>([]);
  const [isImporting, setIsImporting] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const submitMutation = trpc.reviews.submit.useMutation();

  // Parse review text from Airbnb format
  const parseReviews = (text: string): ParsedReview[] => {
    const reviews: ParsedReview[] = [];
    
    // Split by guest name patterns (usually followed by rating)
    // This regex looks for patterns like "Name\nRating: 5 stars" or similar
    const lines = text.split("\n").filter(line => line.trim());
    
    let currentReview: Partial<ParsedReview> = {};
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      // Check for star ratings (5 stars, 4 stars, etc.)
      const starMatch = line.match(/(\d)\s*(?:star|★)/i);
      if (starMatch) {
        currentReview.rating = parseInt(starMatch[1]);
        continue;
      }
      
      // Check if this looks like a review body (longer text)
      if (line.length > 20 && !line.match(/^[A-Z][a-z]+\s*$/)) {
        if (currentReview.guestName && currentReview.rating) {
          currentReview.reviewText = line;
          if (currentReview.guestName && currentReview.rating && currentReview.reviewText) {
            reviews.push({
              guestName: currentReview.guestName,
              rating: currentReview.rating,
              reviewText: currentReview.reviewText,
            });
          }
          currentReview = {};
        }
      } else if (line.match(/^[A-Z][a-z]+(\s+[A-Z][a-z]+)*$/) && line.length < 50) {
        // This looks like a name
        currentReview.guestName = line;
      }
    }
    
    return reviews;
  };

  const handleParse = () => {
    setErrorMessage("");
    setSuccessMessage("");
    
    if (!textInput.trim()) {
      setErrorMessage("Please paste review text");
      return;
    }
    
    const parsed = parseReviews(textInput);
    
    if (parsed.length === 0) {
      setErrorMessage("Could not parse any reviews. Please check the format.");
      return;
    }
    
    setParsedReviews(parsed);
    setSuccessMessage(`Found ${parsed.length} review(s) to import`);
  };

  const handleImport = async () => {
    setIsImporting(true);
    setErrorMessage("");
    
    try {
      for (const review of parsedReviews) {
        await submitMutation.mutateAsync({
          guestName: review.guestName,
          rating: review.rating,
          reviewText: review.reviewText,
        });
      }
      
      setSuccessMessage(`✓ Successfully imported ${parsedReviews.length} review(s)!`);
      setTextInput("");
      setParsedReviews([]);
    } catch (error) {
      setErrorMessage("Failed to import reviews. Please try again.");
      console.error(error);
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 border-sand-dark/20">
        <h2 className="text-2xl font-bold text-charcoal mb-4" style={{ fontFamily: "var(--font-display)" }}>
          Import Reviews from Airbnb
        </h2>
        <p className="text-charcoal-light mb-6" style={{ fontFamily: "var(--font-body)" }}>
          Copy and paste reviews from your Airbnb listing below. The system will automatically parse guest names, ratings, and review text.
        </p>

        {/* Text Input */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-charcoal mb-2">
            Paste Reviews
          </label>
          <textarea
            value={textInput}
            onChange={(e) => {
              setTextInput(e.target.value);
              setErrorMessage("");
            }}
            placeholder="Paste your Airbnb reviews here..."
            className="w-full h-48 px-4 py-3 border border-sand-dark/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-terracotta font-mono text-sm"
          />
        </div>

        {/* Messages */}
        {successMessage && (
          <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
            <CheckCircle size={18} />
            <span>{successMessage}</span>
          </div>
        )}

        {errorMessage && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
            <AlertCircle size={18} />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Buttons */}
        <div className="flex gap-3">
          <Button
            onClick={handleParse}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Upload size={16} />
            Parse Reviews
          </Button>
          <Button
            onClick={handleImport}
            disabled={parsedReviews.length === 0 || isImporting}
            className="flex items-center gap-2 bg-terracotta hover:bg-terracotta-dark text-white"
          >
            {isImporting ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                Importing...
              </>
            ) : (
              <>
                <CheckCircle size={16} />
                Import {parsedReviews.length} Review{parsedReviews.length !== 1 ? "s" : ""}
              </>
            )}
          </Button>
        </div>
      </Card>

      {/* Preview */}
      {parsedReviews.length > 0 && (
        <Card className="p-6 border-sand-dark/20">
          <h3 className="text-lg font-semibold text-charcoal mb-4">Preview</h3>
          <div className="space-y-3">
            {parsedReviews.map((review, index) => (
              <div key={index} className="p-3 bg-warm-white rounded border border-sand-dark/10">
                <div className="flex items-start justify-between mb-2">
                  <p className="font-semibold text-charcoal">{review.guestName}</p>
                  <span className="text-sm text-terracotta">★ {review.rating}/5</span>
                </div>
                <p className="text-sm text-charcoal-light">{review.reviewText}</p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
