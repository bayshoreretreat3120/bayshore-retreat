import { submitReview } from "./server/db";

async function addZdenekReview() {
  try {
    const result = await submitReview({
      guestName: "Zdenek",
      rating: 5,
      reviewText: "We were truly very satisfied, and we can definitely recommend it 100%. We would be happy to stay here again.",
      status: "approved",
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    });

    console.log("✓ Review added successfully");
  } catch (error) {
    console.error("✗ Error adding review:", error);
  }
}

addZdenekReview();
